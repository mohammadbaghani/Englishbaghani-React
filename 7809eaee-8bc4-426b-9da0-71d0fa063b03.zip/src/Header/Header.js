import React, { Component } from 'react'
import './Header.css'

export default class Header extends Component {
    render() {
        return (

            <header>     
                <h1 className='text-todo'>محل یادداشت برنامه هفتگی زبان آموزان </h1>
            </header>

        )
    }
}
